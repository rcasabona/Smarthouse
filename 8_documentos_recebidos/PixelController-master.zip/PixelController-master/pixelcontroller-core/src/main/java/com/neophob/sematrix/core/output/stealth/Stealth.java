/**
 * Copyright (C) 2011-2013 Michael Vogt <michu@neophob.com>
 *
 * This file is part of PixelController.
 *
 * PixelController is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PixelController is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PixelController.  If not, see <http://www.gnu.org/licenses/>.
 */
/*
A nice wrapper class to control the Rainbowduino 

(c) copyright 2009 by rngtng - Tobias Bielohlawek
(c) copyright 2010/2011 by Michael Vogt/neophob.com 
http://code.google.com/p/rainbowduino-firmware/wiki/FirmwareFunctionsReference

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General
Public License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330,
Boston, MA  02111-1307  USA
 */

package com.neophob.sematrix.core.output.stealth;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import com.neophob.sematrix.core.output.NoSerialPortFoundException;
import com.neophob.sematrix.core.output.OutputHelper;
import com.neophob.sematrix.core.output.Serial;
import com.neophob.sematrix.core.output.SerialPortException;
import com.neophob.sematrix.core.properties.ColorFormat;

/**
 * library to communicate with an element stealth led panel via serial port
 *
 * based on the pixelinvaders output by Michael Vogt / neophob.com.
 *
 * @author 
 */
public class Stealth {
		
	/** The log. */
	private static final Logger LOG = Logger.getLogger(Stealth.class.getName());

	/** number of leds horizontal<br> TODO: should be dynamic, someday. */
	public static final int NR_OF_LED_HORIZONTAL = 16;

	/** number of leds vertical<br> TODO: should be dynamic, someday. */
	public static final int NR_OF_LED_VERTICAL = NR_OF_LED_HORIZONTAL;

	/** The Constant BUFFERSIZE. */
	private static final int PANELBUFFERSIZE = NR_OF_LED_HORIZONTAL*NR_OF_LED_VERTICAL;

	// payload buffer is 96 bytes for 24 bit color
	private static final int DATABUFFERSIZE = 96;
	
	/** internal lib version. */
	public static final String VERSION = "1.1";

	/** The Constant START_OF_CMD. */
	private static final byte START_OF_CMD = 0x01;
	
	/** The Constant CMD_SENDFRAME. */
	private static final byte CMD_SENDFRAME = 0x03;
	
	/** The Constant CMD_PING. */
	private static final byte CMD_PING = 0x04;

	/** The Constant START_OF_DATA. */
	private static final byte START_OF_DATA = 0x10;
	
	/** The Constant END_OF_DATA. */
	private static final byte END_OF_DATA = 0x20;

	/** The baud. */
	private int baud = 115200;
	
	/** The port. */
	private Serial port;
	
	/** The arduino heartbeat. */
	private long arduinoHeartbeat;
	
	/** The ack errors. */
	private long ackErrors = 0;
	
	/** The arduino buffer size. */
	private int arduinoBufferSize;
	
	//logical errors reported by arduino, TODO: rename to lastErrorCode
	/** The arduino last error. */
	private int arduinoLastError;
	
	//connection errors to arduino, TODO: use it!
	/** The connection error counter. */
	private int connectionErrorCounter;
		
	/** map to store checksum of image. */	
	private Map<Byte, Long> lastDataMap;
	
	private static Adler32 adler = new Adler32();
	
	/**
	 * Create a new instance to communicate with the Stealth device.
	 *
	 * @param app the app
	 * @throws NoSerialPortFoundException the no serial port found exception
	 */
	public Stealth() throws NoSerialPortFoundException {
		this(null, 0);
	}

	/**
	 * Create a new instance to communicate with the Stealth device.
	 *
	 * @param app the app
	 * @param baud the baud
	 * @throws NoSerialPortFoundException the no serial port found exception
	 */
	public Stealth(int baud) throws NoSerialPortFoundException {
		this(null, baud);
	}

	/**
	 * Create a new instance to communicate with the Stealth device.
	 *
	 * @param app the app
	 * @param portName the port name
	 * @throws NoSerialPortFoundException the no serial port found exception
	 */
	public Stealth(String portName) throws NoSerialPortFoundException {
		this(portName, 0);
	}


	/**
	 * Create a new instance to communicate with the Stealth device.
	 *
	 * @param _app the _app
	 * @param portName the port name
	 * @param baud the baud
	 * @throws NoSerialPortFoundException the no serial port found exception
	 */
	public Stealth(String portName, int baud) throws NoSerialPortFoundException {
		
		LOG.log(Level.INFO,	"Initialize Stealth lib v{0}", VERSION);
		
		lastDataMap = new HashMap<Byte, Long>();
		
		String serialPortName="";
		if(baud > 0) {
			this.baud = baud;
		}
		
		if (portName!=null && !portName.trim().isEmpty()) {
			//open specific port
			LOG.log(Level.INFO,	"open port: {0}", portName);
			serialPortName = portName;
			openPort(portName);
		} else {
			//try to find the port
			String[] ports = Serial.list();
			for (int i=0; port==null && i<ports.length; i++) {
				LOG.log(Level.INFO,	"open port: {0}", ports[i]);
				try {
					serialPortName = ports[i];
					openPort(ports[i]);
				//catch all, there are multiple exception to catch (NoSerialPortFoundException, PortInUseException...)
				} catch (Exception e) {
					// search next port...
				}
			}
		}
				
		if (port==null) {
			throw new NoSerialPortFoundException("Error: no serial port found!");
		}
		
		LOG.log(Level.INFO,	"found serial port: "+serialPortName);
	}


	/**
	 * clean up library.
	 */
	public void dispose() {
		if (connected()) {
			port.stop();
		}
	}



	/**
	 * return the version of the library.
	 *
	 * @return String version number
	 */
	public String version() {
		return VERSION;
	}

	/**
	 * return connection state of lib.
	 *
	 * @return whether a Stealth device is connected
	 */
	public boolean connected() {
		return (port != null);
	}	

	

	/**
	 * Open serial port with given name. Send ping to check if port is working.
	 * If not port is closed and set back to null
	 *
	 * @param portName the port name
	 * @throws NoSerialPortFoundException the no serial port found exception
	 */
	private void openPort(String portName) throws NoSerialPortFoundException {
		if (portName == null) {
			return;
		}
		
		try {
			port = new Serial(portName, this.baud);
			sleep(1500); //give it time to initialize
			if (ping()) {
				return;
			}
			LOG.log(Level.WARNING, "No response from port {0}", portName);
			if (port != null) {
				port.stop();        					
			}
			port = null;
			throw new NoSerialPortFoundException("No response from port "+portName);
		} catch (Exception e) {	
			LOG.log(Level.WARNING, "Failed to open port {0}: {1}", new Object[] {portName, e});
			if (port != null) {
				port.stop();        					
			}
			port = null;
			throw new NoSerialPortFoundException("Failed to open port "+portName+": "+e);
		}	
	}



	/**
	 * send a serial ping command to the arduino board.
	 * 
	 * @return wheter ping was successfull (arduino reachable) or not
	 */
	public boolean ping() {		
		/*
		 *  0   <startbyte>
		 *  1   <i2c_addr>/<offset>
		 *  2   <num_bytes_to_send>
		 *  3   command type, was <num_bytes_to_receive>
		 *  4   data marker
		 *  5   ... data
		 *  n   end of data
		 */
		
		byte cmdfull[] = new byte[7];
		cmdfull[0] = START_OF_CMD;
		cmdfull[1] = 0; //unused here!
		cmdfull[2] = 0x01;
		cmdfull[3] = CMD_PING;
		cmdfull[4] = START_OF_DATA;
		cmdfull[5] = 0x02;
		cmdfull[6] = END_OF_DATA;

		try {
			writeSerialData(cmdfull);
			return waitForAck();			
		} catch (Exception e) {
			return false;
		}
	}
	
	
	/**
	 * wrapper class to send a RGB image to the Stealth device.
	 * the rgb image gets converted to the Stealth device compatible
	 * "image format"
	 *
	 * @param ofs the image ofs
	 * @param data rgb data (int[64], each int contains one RGB pixel)
	 * @param colorFormat the color format
	 * @return true if send was successful
	 */
	public boolean sendRgbFrame(byte ofs, int[] data, ColorFormat colorFormat) {
		//LOG.log(Level.INFO,	"RGB data length: "+data.length);
		if (data.length!=PANELBUFFERSIZE) {
			throw new IllegalArgumentException("data length must be 256 bytes!");
		}
//		return sendFrame(ofs, OutputHelper.convertBufferTo15bit(data, colorFormat));
		return sendFrame(ofs, OutputHelper.convertBufferTo24bit(data, colorFormat));
	}


	
	/**
	 * get md5 hash out of an image. used to check if the image changed
	 *
	 * @param ofs the ofs
	 * @param data the data
	 * @return true if send was successful
	 */
	private boolean didFrameChange(byte ofs, byte data[]) {
		adler.reset();
		adler.update(data);
		long l = adler.getValue();
		
		if (!lastDataMap.containsKey(ofs)) {
			//first run
			lastDataMap.put(ofs, l);
			return true;
		}
		
		if (lastDataMap.get(ofs) == l) {
			//last frame was equal current frame, do not send it!
			return false;
		}
		//update new hash
		lastDataMap.put(ofs, l);
		return true;
	}
	
	/**
	 * send a frame to the active Stealth device.
	 *
	 * @param ofs - the offset get multiplied by 32 on the arduino!
	 * @param data byte[3*8*4]
	 * @return true if send was successful
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	public boolean sendFrame(byte ofs, byte data[]) throws IllegalArgumentException {		
		//LOG.log(Level.INFO,	"data length: "+data.length);
		if (data.length!=(8*DATABUFFERSIZE)) {
			throw new IllegalArgumentException("data length must be 768 bytes! ");
		}
		
		byte ofsOne = (byte)(ofs*2);
		byte ofsTwo = (byte)(ofsOne+1);
		byte ofsThree = (byte)(ofsTwo+1);
		byte ofsFour = (byte)(ofsThree+1);
		byte ofsFive = (byte)(ofsFour+1);
		byte ofsSix = (byte)(ofsFive+1);
		byte ofsSeven = (byte)(ofsSix+1);
		byte ofsEight = (byte)(ofsSeven+1);

		byte frameOne[] = new byte[DATABUFFERSIZE];
		byte frameTwo[] = new byte[DATABUFFERSIZE];
		byte frameThree[] = new byte[DATABUFFERSIZE];
		byte frameFour[] = new byte[DATABUFFERSIZE];
		byte frameFive[] = new byte[DATABUFFERSIZE];
		byte frameSix[] = new byte[DATABUFFERSIZE];
		byte frameSeven[] = new byte[DATABUFFERSIZE];
		byte frameEight[] = new byte[DATABUFFERSIZE];

		boolean returnValue = false;
		
		System.arraycopy(data, 0, frameOne, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE, frameTwo, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*2, frameThree, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*3, frameFour, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*4, frameFive, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*5, frameSix, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*6, frameSeven, 0, DATABUFFERSIZE);
		System.arraycopy(data, DATABUFFERSIZE*7, frameEight, 0, DATABUFFERSIZE);

		byte sendlen = DATABUFFERSIZE;
		byte cmdfull[] = new byte[sendlen+7];
		
		cmdfull[0] = START_OF_CMD;
		//cmdfull[1] = ofs;
		cmdfull[2] = (byte)sendlen;
		cmdfull[3] = CMD_SENDFRAME;
		cmdfull[4] = START_OF_DATA;		
//		for (int i=0; i<sendlen; i++) {
//			cmdfull[5+i] = data[i];
//		}
		cmdfull[sendlen+5] = END_OF_DATA;

		//send frame one
		if (didFrameChange(ofsOne, frameOne)) {
			cmdfull[1] = ofsOne;
			//this is needed due the hardware-wirings 
			flipSecondScanline(cmdfull, frameOne);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				//in case of an error, make sure we send it the next time!
				lastDataMap.put(ofsOne, 0L);
			}
		}		
		//send frame two
		if (didFrameChange(ofsTwo, frameTwo)) {
			cmdfull[1] = ofsTwo;
			flipSecondScanline(cmdfull, frameTwo);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsTwo, 0L);
			}
		}
		//send frame three
		if (didFrameChange(ofsThree, frameThree)) {
			cmdfull[1] = ofsThree;
			flipSecondScanline(cmdfull, frameThree);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsThree, 0L);
			}
		}
		//send frame four
		if (didFrameChange(ofsFour, frameFour)) {
			cmdfull[1] = ofsFour;
			flipSecondScanline(cmdfull, frameFour);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsFour, 0L);
			}
		}
		//send frame Five
		if (didFrameChange(ofsFive, frameFive)) {
			cmdfull[1] = ofsFive;
			flipSecondScanline(cmdfull, frameFive);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsFive, 0L);
			}
		}

		//send frame Six
		if (didFrameChange(ofsSix, frameSix)) {
			cmdfull[1] = ofsSix;
			flipSecondScanline(cmdfull, frameSix);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsSix, 0L);
			}
		}

		//send frame Seven
		if (didFrameChange(ofsSeven, frameSeven)) {
			cmdfull[1] = ofsSeven;
			flipSecondScanline(cmdfull, frameSeven);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsSeven, 0L);
			}
		}

		//send frame Eight
		if (didFrameChange(ofsEight, frameEight)) {
			cmdfull[1] = ofsEight;
			flipSecondScanline(cmdfull, frameEight);
			if (sendSerialData(cmdfull)) {
				returnValue=true;
			} else {
				lastDataMap.put(ofsEight, 0L);
			}
		}

		return returnValue;
	}
	
	/**
	 * this function feed the framebufferdata (32 pixels a 3bytes (aka 24bit)
	 * to the send array. each second scanline gets inverteds
	 *
	 * @param cmdfull the cmdfull
	 * @param frameData the frame data
	 */
	private static void flipSecondScanline(byte cmdfull[], byte frameData[]) {
		for (int i=0; i<16; i++) {
			cmdfull[   5+i] = frameData[i];
			cmdfull[16+5+i] = frameData[i+16];
			cmdfull[32+5+i] = frameData[i+32];
			cmdfull[48+5+i] = frameData[i+48];
			cmdfull[64+5+i] = frameData[i+64];
			cmdfull[80+5+i] = frameData[i+80];
			
		}

	}

	/**
	 * Send serial data.
	 *
	 * @param cmdfull the cmdfull
	 * @return true, if successful
	 */
	private boolean sendSerialData(byte cmdfull[]) {
		try {
			writeSerialData(cmdfull);
			if (waitForAck()) {
				//frame was send successful
				return true;
			}
		} catch (Exception e) {
			LOG.log(Level.WARNING, "sending serial data failed: {0}", e);
		}
		return false;
	}
	
	/**
	 * get last error code from arduino
	 * if the errorcode is between 100..109 - serial connection issue (pc-arduino issue)
	 * if the errorcode is < 100 it's a i2c lib error code (arduino-rainbowduino error)
	 *    check http://arduino.cc/en/Reference/WireEndTransmission for more information
	 *   
	 * @return last error code from arduino
	 */
	public int getArduinoErrorCounter() {
		return arduinoLastError;
	}

	/**
	 * return the serial buffer size of the arduino
	 * 
	 * the buffer is by default 128 bytes - if the buffer is most of the
	 * time almost full (>110 bytes) you probabely send too much serial data.
	 *
	 * @return arduino filled serial buffer size
	 */
	public int getArduinoBufferSize() {
		return arduinoBufferSize;
	}

	/**
	 * per default arduino update this library each 3s with statistic information
	 * this value save the timestamp of the last message.
	 * 
	 * @return timestamp when the last heartbeat receieved. should be updated each 3s.
	 */
	public long getArduinoHeartbeat() {
		return arduinoHeartbeat;
	}
	
	
	/**
	 * how may times the serial response was missing / invalid.
	 *
	 * @return the ack errors
	 */
	public long getAckErrors() {
		return ackErrors;
	}

	/**
	 * send the data to the serial port.
	 *
	 * @param cmdfull the cmdfull
	 * @throws SerialPortException the serial port exception
	 */
	private synchronized void writeSerialData(byte[] cmdfull) throws SerialPortException {
		//TODO handle the 128 byte buffer limit!
		if (port==null) {
			throw new SerialPortException("port is not ready!");
		}
		
		//log.log(Level.INFO, "Serial Wire Size: {0}", cmdfull.length);

		try {
			port.output.write(cmdfull);
			//port.output.flush();
			//DO NOT flush the buffer... hmm not sure about this, processing flush also
			//and i discovered strange "hangs"...
		} catch (Exception e) {
			LOG.log(Level.INFO, "Error sending serial data!", e);
			connectionErrorCounter++;
			throw new SerialPortException("cannot send serial data, errorNr: "+connectionErrorCounter+", Error: "+e);
		}		
	}
	
	/**
	 * read data from serial port, wait for ACK.
	 *
	 * @return true if ack received, false if not
	 */
	private synchronized boolean waitForAck() {		
		//TODO some more tuning is needed here.
		long start = System.currentTimeMillis();
		int timeout=8; //wait up to 50ms
		//log.log(Level.INFO, "wait for ack");
		while (timeout > 0 && port.available() < 2) {
			sleep(4); //in ms
			timeout--;
		}

		if (timeout == 0 && port.available() < 2) {
			LOG.log(Level.INFO, "#### No serial reply, duration: {0}ms ###", System.currentTimeMillis()-start);
			ackErrors++;
			return false;
		}
		//TODO: next method is not very speed/memory efficient!
		byte[] msg = port.readBytes();
		for (int i=0; i<msg.length-1; i++) {
			if (msg[i]== 'A' && msg[i+1]== 'K') {
				try {
					this.arduinoBufferSize = msg[i+2];
					this.arduinoLastError = msg[i+3];
					if (this.arduinoLastError!=0) {
						LOG.log(Level.INFO, "Last Errorcode: {0}", this.arduinoLastError);
					}
				} catch (Exception e) {
					// we failed to update statistics...
				}
				this.arduinoHeartbeat = System.currentTimeMillis();
				if (this.arduinoLastError==0) {
					return true;					
				}
				ackErrors++;
				return false;
				//TODO inconsisten logging!
			}			
		}
		
		String s="";
		for (byte b: msg) {
			s+=(char)b;
		}
		LOG.log(Level.INFO, "Invalid serial data <{0}>, duration: {1}ms", 
				new String[] {s, ""+(System.currentTimeMillis()-start)});
		ackErrors++;
		return false;		
	}


	/**
	 * Sleep wrapper.
	 *
	 * @param ms the ms
	 */
	private void sleep(int ms) {
		try {
			Thread.sleep(ms);
		}
		catch(InterruptedException e) {
		}
	}
	
}
