Element Labs Stealth LED panel

About these panels:
These were a commercial product developed for transparent video walls.

The ATX Hackerspace (Austin TX) obtained a bunch of these panels from a member. Apparently the panels had been RMA'd to the company and were not 100% functional. After some hacking we were able to get a handful of the panels working again.

There was no controller available for this particular panel, but a we were able to scope the output from a similar Element Labs product and figure out the proper data protocol for the panels.

We've been able to drive the panels so far with a custom PIC board as well as Teensy and Maple Mini.

More info here:
http://www.xlvideo.tv/equipment/led/transparent-led/element-labs-stealth/
http://cled.barcousa.com/support/STEALTH/STEALTH_Users_Guide.pdf

