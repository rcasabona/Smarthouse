Teensy (and Arduino) Firmware for PixelInvaders Panels (ws2801 based)

This is the SPI Version of the firmware - you need to use the hardware SPI pins. However the SPI version is much faster than the software SPI (bit banging) firmware.