serialdebug: A processing sketch to test the firmware
tpm2serial: Tested on a Teensy3 using fastspi_2 (https://code.google.com/p/fastspi/) library