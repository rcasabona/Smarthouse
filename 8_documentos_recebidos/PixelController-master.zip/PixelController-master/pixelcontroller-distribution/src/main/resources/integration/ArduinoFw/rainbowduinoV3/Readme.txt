Rainbowduino V3 Firmware
------------------------

Arduino firmware for a Rainbowduino V3 controller of the
'rainbowduino-v3-streaming-firmware' project hosted at:
https://code.google.com/p/rainbowduino-v3-streaming-firmware/

Author: Markus Lang (m@rkus-lang.de)
Blog:   http://programmers-pain.de/