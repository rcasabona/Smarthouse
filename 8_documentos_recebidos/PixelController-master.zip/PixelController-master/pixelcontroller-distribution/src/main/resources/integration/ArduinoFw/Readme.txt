Arduino based firmware files, basically to convert the serial signal to an SPI signal.

Details:
  pixelinvaders: PixelInvader firmware and library files (from http://pixelinvaders.ch).
  rainbowduinoV2: Rainbowduino v2 firmware (from Seeedstudio). Those little devices are EOL.
  rainbowduinoV3: Rainbowduino v3 firmware (from Seeedstudio).
  stealthSpi: Stealth panels firmware (from Element Labs). EOL.
  tpm2net: firmware for the tpm2.net protocol
  tpm2serial: firmware for the tpm2.serial protocol