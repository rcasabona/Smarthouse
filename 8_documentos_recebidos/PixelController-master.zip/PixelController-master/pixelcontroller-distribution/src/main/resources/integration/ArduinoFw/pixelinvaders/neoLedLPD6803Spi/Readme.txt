Teensy (and Arduino) Firmware for PixelInvaders Panels (Lpd6803 based)

Tested on a Teensy 2.0 using Arduino v1.0.5 and Teensyduino v1.14

This is the SPI Version of the firmware - you need to use the hardware SPI pins. 
However the SPI version is much faster than the software SPI (bit banging) firmware.

This is the firmware you should use if you bought a PixelInvaders DIY Kit!

