rxtx library for raspberry pi.

compiled for armv6l-unknown-linux-gnu (3.6.11+ #362 PREEMPT Tue Jan 22 14:52:21 GMT 2013 armv6l GNU/Linux)