module.exports = {
	db: {},
	session_secret: 'test'
}
