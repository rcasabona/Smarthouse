module.exports = {
	db: {
		user: '',
		password: '',
		database: '',
		host: 'localhost',
		port: 5432,
		max: 50,
		idleTimeoutMillis: 30000
	},
	session_secret: ''
}
